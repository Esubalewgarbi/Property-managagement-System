module.exports = {
    secretKey: 'sdfklsdfslfnlj3j5bj35bj4b4',
    localDB: 'mongodb://localhost/realestatedb'
}

