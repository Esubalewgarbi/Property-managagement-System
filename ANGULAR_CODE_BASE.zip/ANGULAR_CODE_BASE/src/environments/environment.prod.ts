export const environment = {
  production: true,
  BASE_URL: 'https://github-realestate.herokuapp.com/api'
};
