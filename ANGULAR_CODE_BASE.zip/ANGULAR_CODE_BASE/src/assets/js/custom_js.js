// $(document).ready(function() {
//     $('.select2-class').select2();
// });